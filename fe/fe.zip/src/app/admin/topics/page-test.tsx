export default function TestPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold">Topics Page Test</h1>
      <p>If you see this, the route is working!</p>
    </div>
  );
}
